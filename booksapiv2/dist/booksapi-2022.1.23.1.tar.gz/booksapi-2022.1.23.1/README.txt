This is a simple sample restful api to play with a book catalog.

